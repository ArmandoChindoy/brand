<?php
$conexion = new mysqli("localhost", "root", "", "operaciones");
?>