<?php
include("Conexion.php");
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$correo=$_POST['correo'];

$query = "INSERT INTO usuario(Nombre, Apellido, Correo) VALUES('$nombre','$apellido', '$correo')";
$resultado = $conexion->query($query);
if ($resultado) {
	header("Location: tabla.php");
}else{
	echo "Insercion no exitosa";
}
?>