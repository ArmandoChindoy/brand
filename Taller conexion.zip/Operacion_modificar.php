<?php
include ("Conexion.php")
$id=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$correo=$_POST['Correo'];

$query = "UPDATE  usuario SET Nombre='$nombre', Apellido='$apellido', Correo='$correo' WHERE Id='$id'";
$resultado = $conexion->query($query);
if ($resultado) {
	header("Location: tabla.php");
}else{
	echo "Insercion no exitosa";
}
?>