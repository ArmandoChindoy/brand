<?php
include("Conexion.php");

$id=$_REQUEST ['Id'];
$query= "DELETE FROM usuario WHERE Id='$id'";
$resultado = $conexion->query($query);
if ($resultado) {
	header("Location: tabla.php");
}else{
	echo "Insercion no exitosa";
}
?>