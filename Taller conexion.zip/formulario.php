<!DOCTYPE html>
<html>
<head>
	<title>Guardar</title>
</head>
<body>
<center>
	<form action="Operacion_guardar.php" method="POST">
		</br></br>
		<input type="text" REQUIRED name="nombre" placeholder="Nombre..." value=""/><br><br>
		<input type="text" REQUIRED name="apellido" placeholder="Apellido..." value=""/><br><br>
		<input type="text" REQUIRED name="correo" placeholder="Correo..." value=""/><br><br>
		<input type="submit" name="Aceptar"/>
	</form>
</center>
</body>
</html>