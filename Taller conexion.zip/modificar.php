<!DOCTYPE html>
<html>
<head>
	<title>Modificar</title>
</head>
<body>
<center>
	<?php
	include("Conexion.php");
	$id=$_REQUEST['Id'];
	$query="SELECT * FROM usuario WHERE Id='$id'";
	$resultado= $conexion->query($query);
	$row= $resultado->fetch_assoc();
	?>
	<form action="Operacion_modificar.php?Id=<?php echo $row['Id']; ?>" method="POST">
	</br></br>
	<input type="text" REQUIRED name="nombre" placeholder="Nombre..." value="<?php echo $row['Nombre']; ?>"/> </br></br>
	<input type="text" REQUIRED name="apellido" placeholder="Apellido..." value="<?php echo $row['Apellido']; ?>"/> </br></br>
	<input type="text" REQUIRED name="correo" placeholder="Correo..." value="<?php echo $row['Correo']; ?>"/> </br></br>
	<input type="submit" name="Aceptar">
</form>
</center>
</body>
</html>