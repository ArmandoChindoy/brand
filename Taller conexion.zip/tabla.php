<html>
<head>
	<title>Tabla</title>
</head>
<body>
<center>
	<table bgcolor="E1DCDC" border="1">
		<thead>
			<tr>
				<th colspan="1"><a href="formulario.php">Nuevo</a></th>
				<th colspan="5">Lista de Usuarios</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Id</td>
				<td>Nombre</td>
				<td>Apellido</td>
				<td>Correo</td>
				<td colspan="2">Operaciones</td>
			</tr>
			<?php
			include("Conexion.php");

			$query = "SELECT * FROM usuario";
			$resultado = $conexion->query($query);
			while($row=$resultado->fetch_assoc()){ 
            ?>
            <tr>
            	<td><?php echo $row['Id']; ?></td>
            	<td><?php echo $row['Nombre']; ?></td>
            	<td><?php echo $row['Apellido']; ?></td>
            	<td><?php echo $row['Correo']; ?></td>
            	<td><a href="modificar.php?Id=<?php echo $row['Id']; ?>">Modificar</a></td>
            	<td><a href="eliminar.php?Id=<?php echo $row['Id']; ?>">Eliminar</a></td>
            </tr>
            <?php
            }
            ?>
		</tbody>
	</table>
</center>
</body>
</html>